package com.example.darling.bitmapcachetest;

import android.app.Application;
import android.content.Context;

import com.jess.arms.base.delegate.AppLifecycles;

public class AppLifecyclesImpl implements AppLifecycles {
    @Override
    public void attachBaseContext(Context base) {

    }

    @Override
    public void onCreate(Application application) {

    }

    @Override
    public void onTerminate(Application application) {

    }
}
